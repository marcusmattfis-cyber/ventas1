import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

export default function TiendaDigital() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products')
      .then((r) => r.json())
      .then((data) => setProducts(data))
      .finally(() => setLoading(false));
  }, []);

  async function handleBuy(productId) {
    setLoading(true);
    try {
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId }),
      });
      const { sessionId } = await res.json();
      const stripe = await stripePromise;
      const { error } = await stripe.redirectToCheckout({ sessionId });
      if (error) console.error(error);
    } catch (err) {
      console.error(err);
      alert('Error creando la sesión de pago');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-900">
      <header className="max-w-6xl mx-auto p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">TD</div>
          <div>
            <h1 className="text-xl font-extrabold">Tienda Digital (Stripe + S3)</h1>
            <p className="text-sm text-gray-600">Pagos seguros y descargas protegidas</p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 pb-24">
        <section className="mt-6">
          <h2 className="text-2xl font-bold mb-4">Productos</h2>
          {loading && <p>Cargando...</p>}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((p) => (
              <article key={p.id} className="bg-white rounded-xl p-5 shadow hover:shadow-md transition">
                <h3 className="font-bold">{p.title}</h3>
                <p className="text-sm text-gray-600">{p.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="text-lg font-bold">S/ {p.pricePerUnit.toFixed(2)}</div>
                  <button
                    onClick={() => handleBuy(p.id)}
                    disabled={loading}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg"
                  >Comprar</button>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="mt-20 p-6 text-center text-sm text-gray-600">© {new Date().getFullYear()} Tienda Digital · Integración Stripe</footer>
    </div>
  );
}
