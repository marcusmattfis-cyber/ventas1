const express = require('express');
const Stripe = require('stripe');
const bodyParser = require('body-parser');
const AWS = require('aws-sdk');
const cors = require('cors');
require('dotenv').config();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const app = express();
app.use(cors());
app.use(bodyParser.json());

const s3 = new AWS.S3({ region: process.env.AWS_REGION });

const PRODUCTS = [
  { id: 'pdf-1', title: 'Guía Productividad 10x', description: 'Ebook práctico', price_cents: 999, s3Key: 'files/pdf-1.pdf' },
  { id: 'presets-1', title: 'Presets Lightroom', description: 'Presets profesionales', price_cents: 1499, s3Key: 'files/presets-1.zip' },
  { id: 'notion-1', title: 'Plantilla Notion', description: 'Plantilla lista', price_cents: 700, s3Key: 'files/notion-1.notion' },
];

app.get('/api/products', (req, res) => {
  const out = PRODUCTS.map(p => ({ id: p.id, title: p.title, description: p.description, pricePerUnit: (p.price_cents/100) }));
  res.json(out);
});

app.post('/api/create-checkout-session', async (req, res) => {
  const { productId } = req.body;
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return res.status(400).json({ error: 'Producto no encontrado' });

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'pen',
            product_data: { name: product.title },
            unit_amount: product.price_cents,
          },
          quantity: 1,
        },
      ],
      success_url: `${process.env.BASE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.BASE_URL}/cancel`,
      metadata: { productId: product.id },
    });

    res.json({ sessionId: session.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error creando sesión' });
  }
});

// Webhook: usa bodyParser.raw y verifica la firma
app.post('/webhook', bodyParser.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.log('Webhook signature verification failed', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const productId = session.metadata.productId;
    const product = PRODUCTS.find(p => p.id === productId);
    if (product) {
      // Generar presigned URL (caduca en 1 hora)
      const params = { Bucket: process.env.S3_BUCKET_NAME, Key: product.s3Key, Expires: 60 * 60 };
      const url = s3.getSignedUrl('getObject', params);

      // Aquí puedes guardar en BD: session.id, session.customer_details.email, url, expiracion
      // Y enviar el URL por email (SendGrid/SES) o almacenarlo y mostrar en /success
      console.log('Presigned URL:', url);
    }
  }

  res.json({ received: true });
});

app.get('/success', (req, res) => {
  res.send('<h1>Pago recibido</h1><p>Revisa tu correo para el enlace de descarga. Si estás en modo prueba, revisa la consola del backend.</p>');
});

app.listen(process.env.PORT || 4242, () => console.log('Server running'));