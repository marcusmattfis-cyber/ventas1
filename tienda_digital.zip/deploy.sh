#!/usr/bin/env bash
echo "Este script solo muestra los pasos. Para desplegar, sube el repo a GitHub e importa en Vercel/Render."
echo "Front-end: Importa en Vercel y configura REACT_APP_STRIPE_PUBLISHABLE_KEY"
echo "Back-end: Importa en Render y añade variables de entorno (STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, AWS creds, S3_BUCKET_NAME)"
