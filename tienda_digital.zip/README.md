# Tienda Digital — Repo listo para deploy

## Qué contiene
- `frontend/`: React app con `TiendaDigital.jsx` (Stripe Checkout frontend).
- `backend/`: Node/Express con endpoints para crear sesiones Stripe, webhook y generación de presigned URLs S3.
- `.env.example`: variables necesarias (no compartas tus claves).

## Pasos rápidos (desarrollo)
1. Copia el repo a tu máquina.
2. Rellena `.env` con tus claves (copia `.env.example` a `.env`).
3. Instalación:
   - Frontend: `cd frontend && npm install`
   - Backend: `cd backend && npm install`
4. Ejecuta:
   - Backend: `cd backend && npm start`
   - Frontend: `cd frontend && npm start`
5. Para probar Webhooks (development): usa `ngrok` para exponer backend y registra la URL en Stripe Dashboard -> Webhooks.

## Despliegue (recomendado)
- Frontend: Vercel (importa el repo, configura `REACT_APP_STRIPE_PUBLISHABLE_KEY` en Variables de Entorno).
- Backend: Render / Railway / Heroku (configura variables de entorno, publica `PORT`).
- Registra la URL pública `/webhook` en Stripe con la clave `STRIPE_WEBHOOK_SECRET`.

## Notas de seguridad
- **Nunca** subas claves secretas a GitHub público.
- Genera presigned URLs con expiración corta (ej. 1 hora) y guarda registros en DB para auditoría.
- Considera usar CloudFront + signed cookies para contenido de video.

## Soporte
Si quieres, puedo:
- Añadir envío de email (SendGrid) con el enlace de descarga.
- Generar workflow de GitHub Actions para deploy automático.
- Preparar `vercel.json` y `render.yaml` para deploy con un clic.
